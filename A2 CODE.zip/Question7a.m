%\\\\\\\\\\\\\\\\\\\ QUESTION 7 /////////////////
%\\\\\\\\\\\\\\\\\\\ (a) //////////////////

%We set
a       =   ones(5,5);
Nh      =   size(a,1);
N2h     =   (size(a,1)-1)/2;
a       =   reshape(a,[1,Nh^2]);
b       =   interpolate(Nh, N2h);
r       =   mtimes(a,b);

full(interpolate(Nh, N2h))

%Our function
function b = interpolate(Nh, N2h)

B       =   zeros(2, 9*N2h^2);
V       =   [];

for j = 1:N2h

    for i = 1:N2h
    
        k       =   (j-1) * N2h + i;

        NW      =   (2*j - 2)*Nh + 2*i - 1;
        N       =   (2*j - 2)*Nh + 2*i;
        NE      =   (2*j - 2)*Nh + 2*i + 1;
        W       =   (2*j - 1)*Nh + 2*i - 1;
        C       =   (2*j - 1)*Nh + 2*i;
        E       =   (2*j - 1)*Nh + 2*i + 1;
        SW      =   (2*j)*Nh + 2*i - 1;
        S       =   (2*j)*Nh + 2*i;
        SE      =   (2*j)*Nh + 2*i + 1;

        B(2, k*9-8:(k+1)*9-9)  =   k*ones(1,9);
        B(1, k*9-8:(k+1)*9-9)  =   [NW, N, NE, W, C, E, SW, S, SE];
        V       =   [V (1/4)*[1/4, 1/2, 1/4, 1/2, 1, 1/2, 1/4, 1/2, 1/4]];

    end
end
%Make into a sparse
b       =   sparse(B(1,:), B(2,:), V);

end