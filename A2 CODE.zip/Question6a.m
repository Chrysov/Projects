%\\\\\\\\\\\\\\\ QUESTION 6 /////////////

%\\\\\\\\\\\\\\\ (a) ////////////////

%We set N and k which are given 
N=127;
%k=10;
k=[1, 10, 20, 40, 80, 100, 120];
%Omega which can be either 2/3 or 1
omega=1;
%Recalling the function
RunA(k,omega,N)
%Recall the function again
RunB(k,omega,N)
%WEIGHTED JACOBI AT N=127
function Question6a=RunA(k,omega,N)
EJ=zeros(7,N);
j=1;
%The first while loop
while j <= 7
    it = 0;
    %We set the A matrix and the f column
    e=ones(N,1);
    A = spdiags([-e,2*e,-e], -1:1, N, N);
    f=zeros(N,1);
    %Setting our v0
    i = (1:1:N);
    v0 = sin((i*k(j)*pi)/(N+1));
    v0 = reshape(v0,[N,1]);
    vnew=v0;
    %The second while loop
    while it < N
        vnew = wJacobi(A,vnew,f,omega);
        EJ(j,it+1)=1/N*sum(vnew.^2,'all')^(0.5);
        it = it+1;
    end
    j=j+1;
end
%FInally plotting it
figure
plot(i, EJ);
title('Weighted Jacobi')
legend('k=1','k=10','k=20','k=40','k=80','k=100','k=120')
end


function vnew = wJacobi(A,vold,f,omega);
%We set the lower and upper matrices without using [lu].
L = -sparse(tril(A,-1));
U = -sparse(triu(A,1));
%We will find the inverse of D without using the inbuilt function
k = [];
%Our for loop
for i=1:size(A,1)
kN = 1/A(i,i);
k = [k kN];
end
%Finally setting our D inverse
Dinverse = diag(k);
%Setting our identity sparse matrix
Identity = speye(size(A,1));
% Set Rj
Rj = Dinverse*(L+U);
%Set Rw
Rw = (1-omega)*Identity+omega*Rj;
% Vnew finally
vnew = Rw*vold+omega*Dinverse*f;
end

%GAUSS-SEIDEL AT N=127
function Question6a1=RunB(k,omega,N)
EJ=zeros(7,N);
j=1;
%The first while loop
while j <= 7
    it = 0;
    %We set the A matrix and the f column
    e=ones(N,1);
    A = spdiags([-e,2*e,-e], -1:1, N, N);
    f=zeros(N,1);
    %Setting our v0
    i = (1:1:N);
    v0 = sin((i*k(j)*pi)/(N+1));
    v0 = reshape(v0,[N,1]);
    vnew=v0;
    %The second while loop
    while it < N
        vnew = Gauss(A,vnew,f);
        EJ(j,it+1)=1/N*sum(vnew.^2,'all')^(0.5);
        it = it+1;
    end
    j=j+1;
end
%FInally plotting it
figure
plot(i, EJ);
title('Gauss Seidel')
legend('k=1','k=10','k=20','k=40','k=80','k=100','k=120')
end

function u = Gauss(A, u0,f)
%Firstly, set the diagonal matrix
D=sparse(diag(diag(A)));
%We define the Lower and Upper triangular matrices of A
%using only primitive functions.
L = -sparse(tril(A,-1));
U = -sparse(triu(A,1));
%We will solve A u =f
%We set D-L as a term
Term=D-L;
%We set the RHS
RHS=U*u0+f;
N=size(A,1);
%Now we create an first guess
u0=zeros(N,1);
for j=1:N
    u0(j)=RHS(j)/Term(j,j);
    for i=j+1:N
        RHS(i)=RHS(i)-Term(i,j)*u0(j);
    end
end
%Set the new u
u=u0;
end
