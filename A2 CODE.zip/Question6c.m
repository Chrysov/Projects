%\\\\\\\\\\\\\\ QUESTION 6 /////////////////

%\\\\\\\\\\\\\\ (c) ///////////////

%The values of N=15,31,63,127 
N = 127;
%With
omega = 2/3;
%Recalling the function
Iterations(N, omega)

function FindThe=Iterations(N, omega)
%Given k and tol
k = 2;
tol = 10^(-6);
%We set the A and f matrices.
e = ones(N,1);
f = zeros(N,1);
A = spdiags([-e,2*e,-e], -1:1, N, N);
%Like the previous comp questions we set
i = (1:1:N);
h = 1/(N+1);
%Set the first v
v0 = sin((i*k*pi)/(N+1));
%Reshape it
v0 = reshape(v0,[N,1]);
%We set the iteration and max iteration.
iteration = 0;
maxit = 100;
%Now onto the older v
vold = v0;
%The Residue
rbefore = f-A*v0;
%Summing them
RBEF = sum(rbefore.^2,'all')^(0.5);
%and
ALT = 1;
while ALT/RBEF > tol
iteration = iteration+1;
%Setting vnew
vnew = wJacobi(A,vold,f,omega);
vold = vnew;
%Taking the difference
Rdif = minus(f,A*vnew);
%Squaring it
RSquared = Rdif.^2;
%Summing all of them
RSummed = sum(RSquared,'all');
%Taking the rot
ALT = RSummed^(0.5);
%
WANTED = iteration;
end
%Show iteration
WANTED
end

%\\\\\\\\\\\\\ FROM QUESTION 4(a) ///////////////

function vnew = wJacobi(A,vold,f,omega)
%We set the lower and upper matrices without using [lu].
L = -sparse(tril(A,-1));
U = -sparse(triu(A,1));
%We will find the inverse of D without using the inbuilt function
k = [];
%Our for loop
for i=1:size(A,1)
kN = 1/A(i,i);
k = [k kN];
end
%Finally setting our D inverse
Dinverse = diag(k);
%Setting our identity sparse matrix
Identity = speye(size(A,1));
% Set Rj
Rj = Dinverse*(L+U);
%Set Rw
Rw = (1-omega)*Identity+omega*Rj;
% Vnew finally
vnew = Rw*vold+omega*Dinverse*f;
end








