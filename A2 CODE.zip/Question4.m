%\\\\\\\\\\\\\ QUESTION 4 //////////////

N = 7;
omega = 1;

VerifyWJ(N, omega)

%\\\\\\\\\\\\\ (a) ////////////////

function vnew = wJacobi(A,vold,f,omega);
%We set the lower and upper matrices without using [lu].
L = -sparse(tril(A,-1));
U = -sparse(triu(A,1));
%We will find the inverse of D without using the inbuilt function
k = [];
%Our for loop
for i=1:size(A,1)
kN = 1/A(i,i);
k = [k kN];
end
%Finally setting our D inverse
Dinverse = diag(k);
%Setting our identity sparse matrix
Identity = speye(size(A,1));
% Set Rj
Rj = Dinverse*(L+U);
%Set Rw
Rw = (1-omega)*Identity+omega*Rj;
% Vnew finally
vnew = Rw*vold+omega*Dinverse*f;
end

%\\\\\\\\\\\\\ (b) //////////////

function u = WJSequence(A,u0,f,omega,tol,maxit);

%Setting our iteration
iteration = 0;
%Setting our vold
vold = u0;
%Setting our 1st r
rbefore = f-A*u0;
%The norm
RBEF = sum(rbefore.^2,'all')^(0.5);
%Our while loop
while iteration < maxit
iteration = iteration+1;
%Setting the vnew
vnew = wJacobi(A,vold,f,omega);
vold = vnew;
% Taking the difference
R = minus(f,A*vnew);
%Taking the square
RSquar = R.^2;
%All together
RSumm = sum(RSquar,'all');
%The root
RRoot = RSumm^(0.5);
%Our if loop
if RRoot/RBEF < tol
iteration = maxit+1;
end
end
u = vnew;
end

%\\\\\\\\\\\\\\ VERIFIER //////////////

function err = VerifyWJ(N, omega)

% Generate a random matrix with strong diagonal dominance
A = rand(N)+N*eye(N);
f = rand(N,1);

% Perform GS relaxation
% zero initial guess
u0=zeros(N,1);
% residual reduction tolerance
tol=1.e-8;
maxit=100;

uWJ = WJSequence(A,u0,f,omega,tol,maxit);

% Compare with the built-in MATLAB solver
err = norm(uWJ - A\f);
end

%OUR ERROR IS ABOUT e-10
%Run the code to see for your self.