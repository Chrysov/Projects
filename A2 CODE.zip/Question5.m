%\\\\\\\\\\\\\\\ QUESTION 5 //////////////
%We set N
N=5;
%Recall the function so we can get the error
VerifyGS(N)

%\\\\\\\\\\\\\\\\ (a) ////////////////

function u = Gauss(A, u0,f)
%Firstly, set the diagonal matrix
D=sparse(diag(diag(A)));
%We define the Lower and Upper triangular matrices of A
%using only primitive functions.
L = -sparse(tril(A,-1));
U = -sparse(triu(A,1));
%We will solve A u =f
%We set D-L as a term
Term=D-L;
%We set the RHS
RHS=U*u0+f;
N=size(A,1);
%Now we create an first guess
u0=zeros(N,1);
for j=1:N
    u0(j)=RHS(j)/Term(j,j);
    for i=j+1:N
        RHS(i)=RHS(i)-Term(i,j)*u0(j);
    end
end
%Set the new u
u=u0;
end

%/////////// (b) /////////////

function u=GSSequence(A,u0,f,tol,maxit)
%We set the iteration, max iteration
iteration=0;
%We know from the notes that the residual is r=f-Av
rbefore=f-A*Gauss(A,u0,f);
%Norm
Rbefore=sum(rbefore.^2,'all')^(0.5);
%Our while loop
while iteration<maxit
    iteration=iteration+1;
    %Set older v
    volder = u0;
    u0=Gauss(A,u0,f);
    %Set the residue
    R=minus(f,A*u0);
    %Squaring it
    RSquared=R.^2;
    %Summing all of them
    RSummed=sum(RSquared,'all');
    %Taking the root
    RSRoot=RSummed^(0.5);
    %if loop within our while loop
    if RSRoot/Rbefore<tol
        iteration=maxit+1;
    end
end
%New u
u=u0;
end

%\\\\\\\\\\\\\ VERIFIER //////////////

function err = VerifyGS(N)
% Generate a random matrix with strong diagonal dominance
A = rand(N)+N*eye(N);
f = rand(N,1);

% Perform GS relaxation
% zero initial guess
u0=zeros(N,1);
% residual reduction tolerance
tol=1.e-8;
maxit=100;

uGS = GSSequence(A,u0,f,tol,maxit);

% Compare with the built-in MATLAB solver
err = norm(uGS - A\f);
end

%OUR ERROR IS ABOUT e-10,e-11.
%Run the code to see for yourself